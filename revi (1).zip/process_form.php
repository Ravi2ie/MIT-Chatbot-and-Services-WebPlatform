<!DOCTYPE html>
<html>
<head>
    <title>Form Submission Status</title>
</head>
<body>

<?php
// Check if the form is submitted
if ($_SERVER["REQUEST_METHOD"] === "POST") {
    // Retrieve form data
    $place = $_POST["place"];
    $name = $_POST["name"];
    $email = $_POST["email"];
    $reg_no = $_POST["reg_no"];

   
            echo "Image uploaded successfully.<br>";
            echo "<h2>Form Submitted Details:</h2>";
            echo "<p>Place to Clean: " . $place . "</p>";
            echo "<p>Name: " . $name . "</p>";
            echo "<p>Email ID: " . $email . "</p>";
            echo "<p>Student Registration Number: " . $reg_no . "</p>";
            echo "<img src='" . $target_file . "' alt='Image of the Place' width='300'>";
        } else {
            echo "Error uploading the image.<br>";
        }

?>

</body>
</html>
