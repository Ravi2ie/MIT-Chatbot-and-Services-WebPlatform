<?php
// Function to generate a random OTP
function generateOTP() {
    return mt_rand(100000, 999999);
}

// Initialize session
session_start();

$generated_otp = '';

// Check if the form is submitted
if ($_SERVER["REQUEST_METHOD"] === "POST") {
    if (isset($_POST['generate'])) {
        // Generate a new OTP
        $generated_otp = generateOTP();
        // Store the generated OTP in session
        $_SESSION['generated_otp'] = $generated_otp;
    } elseif (isset($_POST['verify'])) {
        // Check if the entered OTP matches the generated OTP
        $user_entered_otp = (int)$_POST['user_otp'];
        if ($user_entered_otp === $_SESSION['generated_otp']) {
            $status = 'success';
        } else {
            $status = 'fail';
        }
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>MIT Library OTP Generation</title>
    <style>
        /* Add your CSS styles here */
    </style>
</head>
<body>
    <h1>MIT Library OTP Generation</h1>

    <form action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]); ?>" method="post">
        <button type="submit" name="generate">Generate OTP</button><br>
        <input type="text" name="user_otp">
        <button type="submit" name="verify">Verify OTP</button>
    </form>
    <h3 id="otpDisplay">
        <?php if ($generated_otp !== '') { echo 'Generated OTP: ' . $generated_otp; } ?>
    </h3>

    <?php if (isset($status)) { ?>
        <?php if ($status === 'success') { ?>
            <p>OTP matched successfully. Congratulations!</p>
        <?php } elseif ($status === 'fail') { ?>
            <p>OTP did not match. Please try again.</p>
        <?php } ?>
    <?php } ?>
</body>
</html>
