<?php
session_start();

// Check if the user is logged in

?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>MIT Library Borrow Form</title>
    <style>
        /* Add your CSS styles here */
    </style>
</head>
<body>
    <h1>MIT Library Borrow Form</h1>

    <form action="otp_verification.php" method="post">
        <label for="subject">Subject of the Book:</label>
        <input type="text" id="subject" name="subject" required>

        <label for="genre">Genre of the Book:</label>
        <input type="text" id="genre" name="genre" required>

        <label for="author">Author Name (Optional):</label>
        <input type="text" id="author" name="author">

        <label for="edition">Edition Number (Optional):</label>
        <input type="text" id="edition" name="edition">

        <input type="submit" value="Submit">
    </form>
</body>
</html>
