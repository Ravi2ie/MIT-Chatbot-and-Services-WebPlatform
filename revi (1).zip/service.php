<!DOCTYPE html>
<html>
<head>
    <title>Button Redirect</title>
</head>
<body>
    <h1>Click on a button to navigate:</h1>
    <form method="post" action="">
        <input type="submit" name="mit_cleaner" value="MIT Cleaner">
        <input type="submit" name="outpass_login" value="Outpass Login">
        <input type="submit" name="complaint_mit" value="Complaint MIT">
        <input type="submit" name="mit_transport" value="MIT Transport">
        <input type="submit" name="mit_club" value="MIT Club">
        <input type="submit" name="room_cleaning" value="Room Cleaning">
    </form>

    <?php
    if (isset($_POST['mit_cleaner'])) {
        header("Location: mit_cleaner.php");
        exit;
    } elseif (isset($_POST['outpass_login'])) {
        header("Location: outpass_login.php");
        exit;
    } elseif (isset($_POST['complaint_mit'])) {
        header("Location: complaint_mit.php");
        exit;
    } elseif (isset($_POST['mit_transport'])) {
        header("Location: mit_transport.php");
        exit;
    } elseif (isset($_POST['mit_club'])) {
        header("Location: mit_club.php");
        exit;
    } elseif (isset($_POST['room_cleaning'])) {
        header("Location: room_cleaning.php");
        exit;
    }
    ?>
</body>
</html>
