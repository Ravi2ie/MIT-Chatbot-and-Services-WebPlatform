//room_cleaning.php
<!DOCTYPE html>
<html>
<head>
    <title>Room Cleaning Service</title>
</head>
<body>

<h2>Room Cleaning Service</h2>
<p>Please fill in the details to book a room cleaning service:</p>

<?php
// Check if the form is submitted
if ($_SERVER["REQUEST_METHOD"] === "POST") {
    // Retrieve form data
    $cleaningType = $_POST["cleaning_type"];
    $name = $_POST["name"];
    $email = $_POST["email"];
    $preferredDate = $_POST["preferred_date"];

    

    // Redirect to a new page and show the submitted data in an alert
    echo '<script>
            alert("Data Submitted");
         </script>';
}
?>

<form action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]); ?>" method="post">
    <label for="cleaning_type">Select Cleaning Type:</label>
    <select id="cleaning_type" name="cleaning_type">
        <option value="standard">Standard Cleaning</option>
        <option value="deep">Deep Cleaning</option>
        <option value="special">Special Request</option>
    </select><br><br>

    <label for="name">Your Name:</label>
    <input type="text" id="name" name="name" required><br><br>

    <label for="email">Email ID:</label>
    <input type="email" id="email" name="email" required><br><br>

    <label for="preferred_date">Preferred Date:</label>
    <input type="datetime-local" id="preferred_date" name="preferred_date" required><br><br>

    <input type="submit" value="Book Service">
</form>

</body>
</html>
