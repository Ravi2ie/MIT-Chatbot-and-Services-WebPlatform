<!DOCTYPE html>
<html>
<head>
    <title>MIT Services</title>
</head>
<body>

<h1>MIT Services</h1>

<!-- Section buttons -->
<button onclick="showTable('clean_data')">MIT Cleaner</button>
<button onclick="showTable('bookings')">MIT Room Cleaning</button>
<button onclick="showTable('complaints')">Complaints of MIT</button>
<button onclick="showTable('transportation_requests')">MIT Transport</button>
<button onclick="showTable('club_registration')">MIT Club</button>


<!-- Display table function -->
<script>
function showTable(tableName) {
    const xhr = new XMLHttpRequest();

    xhr.onreadystatechange = function () {
        if (xhr.readyState === XMLHttpRequest.DONE) {
            if (xhr.status === 200) {
                document.getElementById('tableDiv').innerHTML = xhr.responseText;
            } else {
                alert('Error fetching data from the server.');
            }
        }
    };

    xhr.open('GET', 'fetch_data.php?table=' + tableName, true);
    xhr.send();
}
</script>
<!-- <script>
        function viewed() {
            // Redirect to the desired PHP file passing the data as a query parameter
            window.location.href = "outpass_login.php?data=" + encodeURIComponent();
        }
    </script> -->

<!-- Div to display the table -->
<div id="tableDiv">
    <!-- Table data will be displayed here -->
</div>

</body>
</html>
