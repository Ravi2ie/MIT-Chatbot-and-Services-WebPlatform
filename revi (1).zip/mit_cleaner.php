
//mit_cleaner.php
<!DOCTYPE html>
<html>
<head>
    <title>Trash Cleaning Form</title>
</head>
<body>

<?php
// Check if the form is submitted
if ($_SERVER["REQUEST_METHOD"] === "POST") {
    // Database connection configuration
    $servername = "localhost";  // Change this if your database is hosted on a different server
    $username = "root";  // Replace with your database username
    $password = "";  // Replace with your database password
    $dbname = "clean";  // Replace with your database name

    // Create a connection
    $conn = new mysqli($servername, $username, $password, $dbname);

    // Check connection
    if ($conn->connect_error) {
        die("Connection failed: " . $conn->connect_error);
    }

    // Sanitize and store the form data
    $place = test_input($_POST["place"]);
    $name = test_input($_POST["name"]);
    $email = test_input($_POST["email"]);
    $reg_no = test_input($_POST["reg_no"]);

   

    // Insert data into the clean_data table
    $sql = "INSERT INTO clean_data (place, image, name, email, reg_no) VALUES ('$place', '$image', '$name', '$email', '$reg_no')";

    if ($conn->query($sql) === TRUE) {
        echo "<script>alert('Form submitted successfully!');</script>";
    } else {
        echo "<script>alert('Error: " . $sql . "<br>" . $conn->error . "');</script>";
    }

    // Close the database connection
    $conn->close();
}

// Function to sanitize form inputs
function test_input($data) {
    $data = trim($data);
    $data = stripslashes($data);
    $data = htmlspecialchars($data);
    return $data;
}
?>

<h2>Trash Cleaning Form</h2>
<p>Please fill in the details to request trash cleaning in your college:</p>

<form action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]); ?>" method="post" enctype="multipart/form-data">
    <label for="place">Place to Clean:</label>
    <input type="text" id="place" name="place" required><br><br>

    <label for="image">Image of the Place:</label>
    <input type="file" id="image" name="image" accept="image/*" required><br><br>

    <label for="name">Your Name:</label>
    <input type="text" id="name" name="name" required><br><br>

    <label for="email">Email ID:</label>
    <input type="email" id="email" name="email" required><br><br>

    <label for="reg_no">Student Registration Number:</label>
    <input type="text" id="reg_no" name="reg_no" required><br><br>

    <input type="submit" value="Submit">
</form>

</body>
</html>

