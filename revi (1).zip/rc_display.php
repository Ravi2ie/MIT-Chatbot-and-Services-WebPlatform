<!DOCTYPE html>
<html>
<head>
    <style>
        table {
            width: 100%;
            border-collapse: collapse;
        }

        th, td {
            padding: 8px;
            text-align: left;
            border-bottom: 1px solid #ddd;
        }

        th {
            background-color: #4CAF50;
            color: white;
        }

        tr:nth-child(even) {
            background-color: #f2f2f2;
        }

        tr:hover {
            background-color: #ddd;
        }
    </style>
</head>
<body>

<?php
// Create database connection
$conn = mysqli_connect('localhost', 'root', '', 'ravi');

// Check connection
if (!$conn) {
    die("Connection failed: " . mysqli_connect_error());
}

// Retrieve data from the table
$select = 'SELECT * FROM ravi';
$result = mysqli_query($conn, $select);

// Check if there are any rows returned
if (mysqli_num_rows($result) > 0) {
    echo '<table>';
    echo '<tr>
            <th>Register Number</th>
            <th>Details</th>
          </tr>';

    while ($row = mysqli_fetch_array($result)) {
        echo '<tr>
                <td>' . $row['register_no'] . '</td>
                <td>' . $row['details'] . '</td>
              </tr>';
    }

    echo '</table>';
} else {
    echo 'No data found.';
}

// Close the database connection
mysqli_close($conn);
?>

</body>
</html>
