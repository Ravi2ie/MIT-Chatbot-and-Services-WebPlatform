//mit_transport.php
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>MIT College Transportation Service</title>
    <style>
        /* Add your CSS styles here */
    </style>
</head>
<body>
    <h1>MIT College Transportation Service</h1>

    <form action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]); ?>" method="post">
        <label for="name">Your Name:</label>
        <input type="text" id="name" name="name" required><br>

        <label for="email">Email Address:</label>
        <input type="email" id="email" name="email" required><br>

        <label for="phone">Phone Number:</label>
        <input type="tel" id="phone" name="phone" required><br>

        <label for="pickup">Pickup Location:</label>
        <input type="text" id="pickup" name="pickup" required><br>

        <label for="dropoff">Drop-off Location:</label>
        <input type="text" id="dropoff" name="dropoff" required><br>

        <label for="date">Date:</label>
        <input type="date" id="date" name="date" required><br>

        <label for="time">Time:</label>
        <input type="time" id="time" name="time" required><br>

        <label for="transport_type">Type of Transportation:</label>
        <select id="transport_type" name="transport_type" required>
            <option value="">Select Transportation Type</option>
            <option value="Car">Car</option>
            <option value="Bus">Bus</option>
        </select><br>

        <label for="passengers">Number of Passengers:</label>
        <input type="number" id="passengers" name="passengers" min="1" required><br>

        <label for="special_requirements">Special Requirements:</label>
        <textarea id="special_requirements" name="special_requirements" rows="4" cols="40"></textarea><br>

        <input type="checkbox" id="terms" name="terms" required>
        <label for="terms">I agree to the terms and conditions</label><br>

        <input type="submit" name="submit" value="Submit">
    </form>

    <?php
    // Check if the form is submitted
    if ($_SERVER["REQUEST_METHOD"] === "POST" && isset($_POST['submit'])) {
        // Retrieve form data
        $pickup = $_POST["pickup"];
        $dropoff = $_POST["dropoff"];
        $date = $_POST["date"];
        $time = $_POST["time"];
        $transport_type = $_POST["transport_type"];
        $passengers = (int)$_POST["passengers"];
        $special_requirements = $_POST["special_requirements"];
        $name = $_POST["name"];
        $email = $_POST["email"];
        $phone = $_POST["phone"];

        // Database configuration
        $servername = "localhost";
        $username = "root";
        $password = "";
        $dbname = "transport";

        // Create a connection to the database
        $conn = new mysqli($servername, $username, $password, $dbname);

        // Check the connection
        if ($conn->connect_error) {
            die("Connection failed: " . $conn->connect_error);
        }

        // Create the table if it does not exist
        $createTableQuery = "CREATE TABLE IF NOT EXISTS transportation_requests (
            id INT(11) AUTO_INCREMENT PRIMARY KEY,
            pickup_location VARCHAR(100) NOT NULL,
            dropoff_location VARCHAR(100) NOT NULL,
            date DATE NOT NULL,
            time TIME NOT NULL,
            transport_type VARCHAR(50) NOT NULL,
            passengers INT(11) NOT NULL,
            special_requirements TEXT,
            name VARCHAR(100) NOT NULL,
            email VARCHAR(100) NOT NULL,
            phone VARCHAR(20) NOT NULL
        )";

        if ($conn->query($createTableQuery) === FALSE) {
            die("Error creating table: " . $conn->error);
        }

        // Prepare and execute the SQL query to insert the data into the database
        $sql = "INSERT INTO transportation_requests (pickup_location, dropoff_location, date, time, transport_type, passengers, special_requirements, name, email, phone) VALUES ('$pickup', '$dropoff', '$date', '$time', '$transport_type', $passengers, '$special_requirements', '$name', '$email', '$phone')";

        if ($conn->query($sql) === TRUE) {
            // Display a success message using JavaScript alert
            echo '<script>alert("Thank you for submitting your transportation request. We will get back to you soon. Please stay tuned for further updates.");</script>';
        } else {
            echo "Error: " . $sql . "<br>" . $conn->error;
        }

        // Close the database connection
        $conn->close();
    }
    ?>
</body>
</html>
