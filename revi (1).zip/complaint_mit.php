//complaint_mit.php
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>MIT College Complaint Form</title>
    <style>
        /* (styles remain the same) */
    </style>
</head>
<body>
    <h1>MIT College Complaint Form</h1>

    <?php
    // Check if the form is submitted
    if ($_SERVER["REQUEST_METHOD"] === "POST") {
        $category = $_POST["category"];
        $details = $_POST["details"];
        $name = $_POST["name"];
        $email = $_POST["email"];
        $phone = $_POST["phone"];

        // Database configuration
        $servername = "localhost";
        $username = "root";
        $password = "";
        $dbname = "complaint";

        // Create a connection to the database
        $conn = new mysqli($servername, $username, $password, $dbname);

        // Check the connection
        if ($conn->connect_error) {
            die("Connection failed: " . $conn->connect_error);
        }

        // Create the table if it does not exist
        $createTableQuery = "CREATE TABLE IF NOT EXISTS complaints (
            id INT(11) AUTO_INCREMENT PRIMARY KEY,
            category VARCHAR(100) NOT NULL,
            details TEXT NOT NULL,
            name VARCHAR(100) NOT NULL,
            email VARCHAR(100) NOT NULL,
            phone VARCHAR(20) NOT NULL
        )";

        if ($conn->query($createTableQuery) === FALSE) {
            die("Error creating table: " . $conn->error);
        }

        // Prepare and execute the SQL query to insert the data into the database
        $sql = "INSERT INTO complaints (category, details, name, email, phone) VALUES ('$category', '$details', '$name', '$email', '$phone')";

        if ($conn->query($sql) === TRUE) {
            echo '<script>
                    alert("Complaint submitted successfully!");
                    window.location.href = "complaint_mit.php";
                  </script>';
        } else {
            echo "Error: " . $sql . "<br>" . $conn->error;
        }

        // Close the database connection
        $conn->close();
    } else {
    ?>

    <form action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]); ?>" method="post">
        <label for="category">Complaint Category:</label>
        <select id="category" name="category" required>
            <option value="">Select Category</option>
            <option value="Academics">Academics</option>
            <option value="Facilities">Facilities</option>
            <option value="Faculty">Faculty</option>
            <option value="Administrative">Administrative</option>
            <option value="Other">Other</option>
        </select>

        <label for="details">Complaint Details:</label>
        <textarea id="details" name="details" placeholder="Enter your complaint details here" required></textarea>

        <label for="name">Your Name:</label>
        <input type="text" id="name" name="name" required>

        <label for="email">Email Address:</label>
        <input type="email" id="email" name="email" required>

        <label for="phone">Phone Number:</label>
        <input type="text" id="phone" name="phone" required>

        <input type="submit" value="Submit Complaint">
    </form>

    <?php
    }
    ?>
</body>
</html>
