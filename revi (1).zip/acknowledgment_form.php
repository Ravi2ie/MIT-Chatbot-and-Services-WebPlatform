<?php
session_start();

// Check if the user is logged in


// Check if the OTP is submitted and correct
if ($_SERVER["REQUEST_METHOD"] === "POST" && isset($_SESSION['otp'])) {
    $submitted_otp = $_POST['otp'];
    $correct_otp = $_SESSION['otp'];

    if ($submitted_otp === $correct_otp) {
        // OTP is correct, display acknowledgment message
        unset($_SESSION['otp']); // Clear OTP from session
    } else {
       
        // Incorrect OTP, redirect back to OTP verification page
        echo 'hi';
        // header('Location: otp_verification.php');
        exit;
    }
} else {
    
    // Redirect back to OTP verification page if OTP is not submitted
    // header('Location: otp_verification.php');
    echo 'hiii';
    exit;
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>MIT Library Acknowledgment</title>
    <style>
        /* Add your CSS styles here */
    </style>
</head>
<body>
    <h1>MIT Library Acknowledgment</h1>

    <p>Your borrowing details have been successfully submitted and verified.</p>
    <p>Thank you for using the MIT College Library.</p>
</body>
</html>
